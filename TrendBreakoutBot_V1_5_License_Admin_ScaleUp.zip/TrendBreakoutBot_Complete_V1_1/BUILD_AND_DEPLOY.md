# TrendBreakoutBot MT5 Signal V1.3

Android signal/trade-plan assistant for manual MT5 execution.

## Added in V1.3
- Risk-based lot-size calculation using broker/symbol tick value and tick size supplied by the user.
- Account balance input (for example R50).
- Configurable risk percentage (default 1%).
- Configurable account-level running-profit target (for example R100000).
- Long-hold management guidance: SL/TP remain in the trade plan; an account-level profit target is displayed.
- Safety refusal when calculated lot size is below 0.01 lots rather than forcing a broker minimum that could exceed the risk budget.

## Important MT5 limitation
MT5 Android cannot host custom Expert Advisors or provide direct automatic order execution for this app. This package is therefore signal-only/manual execution. Automatic placement and long-running order management require a broker-supported execution API or a desktop/VPS terminal.

## Build
Open the `android` folder in an Android Gradle IDE and build a debug APK. Install the resulting APK on Android.
