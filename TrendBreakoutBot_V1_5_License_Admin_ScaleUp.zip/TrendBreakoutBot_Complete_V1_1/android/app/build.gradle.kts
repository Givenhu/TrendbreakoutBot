plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.trendbreakoutbot"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.trendbreakoutbot"
        minSdk = 26
        targetSdk = 35
        versionCode = 13
        versionName = "1.3.0-signal"
    }
}


dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
