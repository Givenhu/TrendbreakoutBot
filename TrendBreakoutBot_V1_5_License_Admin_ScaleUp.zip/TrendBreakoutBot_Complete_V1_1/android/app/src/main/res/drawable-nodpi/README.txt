Background artwork for TrendBreakoutBot Signal V1.4.
