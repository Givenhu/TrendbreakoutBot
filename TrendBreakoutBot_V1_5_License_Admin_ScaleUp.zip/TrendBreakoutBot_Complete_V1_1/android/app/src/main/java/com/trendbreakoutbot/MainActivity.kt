package com.trendbreakoutbot

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.text.InputType
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var result: TextView
    private lateinit var mode: RadioGroup
    private lateinit var license: LicenseManager
    private val channelId = "tbb_alerts"

    private fun field(hint: String): EditText = EditText(this).apply {
        this.hint = hint
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setSingleLine(true)
        setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
    }
    private fun value(e: EditText): Double? = e.text.toString().trim().toDoubleOrNull()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        license = LicenseManager(this)
        createNotificationChannel()
        if (!license.isActive()) { showLicenseScreen(); return }
        showMainScreen()
    }

    private fun showLicenseScreen() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(36, 36, 36, 36) }
        root.setBackgroundColor(Color.rgb(12,12,12))
        val title = TextView(this).apply { text = "TrendBreakoutBot"; textSize = 30f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        val sub = TextView(this).apply { text = "Powered by G.J.B\n\n30-Day License Activation"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 10, 0, 24) }
        val key = EditText(this).apply { hint = "Enter license key"; setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) } 
        val activate = Button(this).apply { text = "ACTIVATE LICENSE" }
        val admin = Button(this).apply { text = "ADMIN" }
        val status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 18, 0, 0) }
        root.addView(title); root.addView(sub); root.addView(key, LinearLayout.LayoutParams(-1, -2)); root.addView(activate); root.addView(admin); root.addView(status)
        activate.setOnClickListener { if (license.activate(key.text.toString())) { status.text = "License active for 30 days."; showMainScreen() } else status.text = "Invalid or expired license key." }
        admin.setOnClickListener { showAdminScreen() }
        setContentView(root)
    }

    private fun showAdminScreen() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 28, 28, 28) }; root.setBackgroundColor(Color.rgb(12,12,12))
        val title = TextView(this).apply { text = "TrendBreakoutBot Admin\nPowered by G.J.B"; textSize = 24f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE) }
        val pin = EditText(this).apply { hint = "Admin PIN (default: 1234)"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        val enter = Button(this).apply { text = "OPEN ADMIN" }
        val out = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f }
        root.addView(title); root.addView(pin); root.addView(enter); root.addView(out)
        enter.setOnClickListener {
            if (pin.text.toString() != "1234") { out.text = "Wrong PIN."; return@setOnClickListener }
            root.removeAllViews(); root.addView(title); val create = Button(this).apply { text = "GENERATE 30-DAY KEY" }; val list = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f }
            val back = Button(this).apply { text = "BACK TO ACTIVATION" }; root.addView(create); root.addView(list); root.addView(back)
            fun refresh() { list.text = license.adminKeys().joinToString("\n") { (k,e) -> "$k  •  ${license.formatDate(e)}" }.ifBlank { "No keys yet." } }
            refresh()
            create.setOnClickListener { val k = license.create30DayKey(); Toast.makeText(this, "New key: $k", Toast.LENGTH_LONG).show(); refresh() }
            back.setOnClickListener { showLicenseScreen() }
        }
        setContentView(root)
    }

    private fun showMainScreen() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 24, 28, 28) }
        val content = FrameLayout(this)
        val background = ImageView(this).apply { setImageResource(R.drawable.trendbreakout_background); scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0.34f }
        content.addView(background, FrameLayout.LayoutParams(-1, -1))
        content.addView(View(this).apply { setBackgroundColor(Color.argb(155,0,0,0)) }, FrameLayout.LayoutParams(-1,-1))
        content.addView(ScrollView(this).apply { addView(root); isFillViewport = true }, FrameLayout.LayoutParams(-1,-1))
        root.addView(TextView(this).apply { text = "TrendBreakoutBot Signal"; textSize = 28f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE) })
        root.addView(TextView(this).apply { text = "Powered by G.J.B\nLicense: ${license.daysLeft()} days remaining"; textSize = 14f; setTextColor(Color.WHITE); setPadding(0,0,0,18) })
        mode = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL; gravity = Gravity.CENTER }
        mode.addView(RadioButton(this).apply { text = "SCALP"; id=1001 }); mode.addView(RadioButton(this).apply { text = "SWING"; id=1002 }); mode.check(1001); root.addView(mode)
        root.addView(TextView(this).apply { text = "Manual signal + trade-plan assistant. Scale-up alerts are generated when an existing trade is profitable and a new independent setup is confirmed."; textSize=14f; setTextColor(Color.WHITE); setPadding(0,12,0,18) })
        val price=field("Current price"); val fast=field("EMA 20"); val slow=field("EMA 50"); val hi=field("Breakout level / recent high"); val lo=field("Breakout level / recent low"); val r=field("Higher-timeframe resistance"); val s=field("Higher-timeframe support"); val body=field("Last candle body % (e.g. 70)"); val account=field("Account balance (R) — e.g. 50"); val riskPct=field("Risk per trade % — default 1"); val tv=field("MT5 tick value for 1.00 lot"); val ts=field("MT5 tick size"); val target=field("Running-profit close target (R) — e.g. 5000"); val running=field("Current open trade profit (R) — e.g. 5"); val openTrades=field("Current open trades — e.g. 1")
        listOf(price,fast,slow,hi,lo,r,s,body,account,riskPct,tv,ts,target,running,openTrades).forEach { root.addView(it) }
        val analyse=Button(this).apply { text="ANALYSE + CALCULATE LOT" }; root.addView(analyse)
        val scale=Button(this).apply { text="CHECK SCALE-UP OPPORTUNITY" }; root.addView(scale)
        result=TextView(this).apply { text="SIGNAL: WAIT"; textSize=18f; setTypeface(null,Typeface.BOLD); setTextColor(Color.WHITE); setPadding(0,22,0,22) }; root.addView(result)
        root.addView(TextView(this).apply { text="30-day license is active. This version is MT5 signal-only; it does not place trades automatically. cTrader remains excluded for now."; textSize=13f; setTextColor(Color.WHITE) })

        fun calculate(): String? {
            val p=value(price); val e20=value(fast); val e50=value(slow); val high=value(hi); val low=value(lo); val resist=value(r); val support=value(s); val b=value(body)?:0.0; val bal=value(account)?:0.0; val rp=(value(riskPct)?:1.0).coerceAtLeast(0.0); val tickV=value(tv); val tickS=value(ts)
            if(listOf(p,e20,e50,high,low,resist,support).any{it==null}) { result.text="SIGNAL: WAIT\nComplete the required chart fields."; return null }
            val pv=p!!; val ema20=e20!!; val ema50=e50!!; val h=high!!; val l=low!!; val resistance=resist!!; val supportV=support!!; val buy=ema20>ema50 && pv>h && b>=60; val sell=ema20<ema50 && pv<l && b>=60; val sl=if(buy) maxOf(supportV,ema50) else if(sell) minOf(resistance,ema50) else 0.0; val dist=abs(pv-sl); val tp=if(buy) pv+dist*2 else if(sell) pv-dist*2 else 0.0; val riskAmount=bal*rp/100.0; val lot=if((buy||sell)&&tickV!=null&&tickS!=null&&tickV>0&&tickS>0&&dist>0&&riskAmount>0){ kotlin.math.floor((riskAmount/((dist/tickS)*tickV))*100)/100 } else 0.0; val name=if(mode.checkedRadioButtonId==1001)"SCALP" else "SWING"; result.text=when{buy->"SIGNAL: BUY ▲\nMode: $name\nEntry: ${fmt(pv)}\nSL: ${fmt(sl)}\nTP (1:2): ${fmt(tp)}\nRisk budget: R${fmt2(riskAmount)}\nLot: ${if(lot>=0.01)fmt2(lot) else "0.00 — do not force minimum lot"}"; sell->"SIGNAL: SELL ▼\nMode: $name\nEntry: ${fmt(pv)}\nSL: ${fmt(sl)}\nTP (1:2): ${fmt(tp)}\nRisk budget: R${fmt2(riskAmount)}\nLot: ${if(lot>=0.01)fmt2(lot) else "0.00 — do not force minimum lot"}"; else->"SIGNAL: WAIT\nMode: $name\nNo complete trend + breakout + candle-confirmation setup."}; return if(buy||sell) if(buy)"BUY" else "SELL" else null
        }
        analyse.setOnClickListener { calculate() }
        scale.setOnClickListener {
            val signal=calculate(); val profit=value(running)?:0.0; val count=(value(openTrades)?:0.0).toInt(); if(signal!=null && profit>0 && count>=1){ sendNotification("SCALE-UP OPPORTUNITY", "$signal setup confirmed while existing trade is +R${fmt2(profit)}. Review risk before adding."); Toast.makeText(this,"Scale-up alert sent",Toast.LENGTH_SHORT).show() } else { Toast.makeText(this,"No scale-up alert: existing trade must be profitable and a new setup must be confirmed.",Toast.LENGTH_LONG).show() }
        }
        setContentView(content)
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),77)
    }
    private fun sendNotification(title:String,text:String){ val nm=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager; val b=androidx.core.app.NotificationCompat.Builder(this,channelId).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(text).setStyle(androidx.core.app.NotificationCompat.BigTextStyle().bigText(text)).setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH).build(); nm.notify((System.currentTimeMillis()%100000).toInt(),b) }
    private fun createNotificationChannel(){ val nm=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager; nm.createNotificationChannel(NotificationChannel(channelId,"Trading alerts",NotificationManager.IMPORTANCE_HIGH)) }
    private fun fmt(x:Double)=String.format(Locale.US,"%.5f",x); private fun fmt2(x:Double)=String.format(Locale.US,"%.2f",x)
}
