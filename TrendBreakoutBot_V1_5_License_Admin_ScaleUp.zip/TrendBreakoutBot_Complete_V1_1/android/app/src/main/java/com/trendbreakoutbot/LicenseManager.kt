package com.trendbreakoutbot

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

class LicenseManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("tbb_license", Context.MODE_PRIVATE)
    private val adminPrefs = context.getSharedPreferences("tbb_admin", Context.MODE_PRIVATE)

    fun activate(key: String): Boolean {
        val record = adminPrefs.getString("key_${key.trim().uppercase(Locale.US)}", null) ?: return false
        val expiry = record.toLongOrNull() ?: return false
        if (expiry <= System.currentTimeMillis()) return false
        prefs.edit().putString("key", key.trim().uppercase(Locale.US)).putLong("expiry", expiry).apply()
        return true
    }

    fun isActive(): Boolean = prefs.getLong("expiry", 0L) > System.currentTimeMillis()
    fun daysLeft(): Long = TimeUnit.MILLISECONDS.toDays((prefs.getLong("expiry", 0L) - System.currentTimeMillis()).coerceAtLeast(0L))
    fun activeKey(): String = prefs.getString("key", "") ?: ""

    fun create30DayKey(): String {
        val key = "GJB-30-${UUID.randomUUID().toString().replace("-", "").take(10).uppercase(Locale.US)}"
        val expiry = System.currentTimeMillis() + TimeUnit.DAYS.toMillis(30)
        adminPrefs.edit().putLong("key_$key", expiry).apply()
        return key
    }

    fun revoke(key: String) { adminPrefs.edit().remove("key_${key.trim().uppercase(Locale.US)}").apply() }

    fun adminKeys(): List<Pair<String, Long>> {
        return adminPrefs.all.filterKeys { it.startsWith("key_") }.mapNotNull { (k, v) ->
            val expiry = (v as? Long) ?: return@mapNotNull null
            k.removePrefix("key_") to expiry
        }.sortedBy { it.second }
    }

    fun formatDate(ms: Long): String = SimpleDateFormat("dd MMM yyyy", Locale.US).format(Date(ms))
}
