# TrendBreakoutBot

## V1.5 — Signal + 30-day licensing + scale-up alerts

Branding: **TrendBreakoutBot — Powered by G.J.B**

This build is intentionally simple and phone-friendly. cTrader is excluded for now.

### Included
- SCALP / SWING modes
- Manual MT5 signal and trade-plan calculations
- Risk-based lot-size calculation
- Running-profit target field
- 30-day license activation
- Simple local Admin panel for generating 30-day keys
- License countdown and expiry lock
- Manual scale-up opportunity check and Android notification
- Trading-style background

### License note
This V1.5 license/admin system is a **local prototype**. It does not use a cloud server, so it is simple and uses almost no mobile data. For a commercial release, a server-backed license service should replace the local key store so keys can be remotely revoked and protected across devices.

### Scale-up note
The app only alerts when the user enters a profitable existing trade and the current chart inputs independently produce a new BUY/SELL setup. It does not automatically add positions. cTrader/automatic execution remains out of scope for this version.
