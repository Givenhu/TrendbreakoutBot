// TrendBreakoutBot 1.1 - unified scalp/swing MT5 Expert Advisor
// DEMO-FIRST. Backtest + forward-test before live trading.
#property strict
#property version "1.1.0"
#include <Trade/Trade.mqh>
CTrade trade;

enum TradeMode { MODE_SCALP=0, MODE_SWING=1 };
input TradeMode InpMode=MODE_SCALP;
input double RiskPercent=1.0;
input double EmergencyDailyDrawdownPct=40.0;
input int MaxEAPositions=1;
input int MaxTradesPerDay=5;
input int CooldownMinutes=30;
input int MaxSpreadPoints=50;
input int FastEMA=20;
input int SlowEMA=50;
input int ATRPeriod=14;
input double ATRSLMult=1.5;
input double RiskReward=2.0;
input int BreakoutLookback=20;
input int SRLookback=100;
input double MinBodyATR=0.20;
input bool RequireBodyConfirmation=true;
input bool RequireRetest=false;
input int SessionStartHour=7;
input int SessionEndHour=21;
input ulong Magic=26090401;

int g_day=-1; double g_dayEquity=0; bool g_halted=false; datetime g_lastTrade=0;

ENUM_TIMEFRAMES EntryTF(){return InpMode==MODE_SCALP?PERIOD_M5:PERIOD_H1;}
ENUM_TIMEFRAMES TrendTF(){return InpMode==MODE_SCALP?PERIOD_M15:PERIOD_H4;}
ENUM_TIMEFRAMES SRTF(){return InpMode==MODE_SCALP?PERIOD_H1:PERIOD_H4;}

void ResetDay(){MqlDateTime d; TimeToStruct(TimeCurrent(),d); g_day=d.day_of_year; g_dayEquity=AccountInfoDouble(ACCOUNT_EQUITY); g_halted=false;}
bool DailyGuard(){MqlDateTime d; TimeToStruct(TimeCurrent(),d); if(g_day<0||d.day_of_year!=g_day) ResetDay(); if(g_dayEquity<=0)return false; double dd=(g_dayEquity-AccountInfoDouble(ACCOUNT_EQUITY))/g_dayEquity*100.0; if(dd>=EmergencyDailyDrawdownPct)g_halted=true; return !g_halted;}

bool InSession(){MqlDateTime d; TimeToStruct(TimeCurrent(),d); if(SessionStartHour==SessionEndHour)return true; if(SessionStartHour<SessionEndHour)return d.hour>=SessionStartHour&&d.hour<SessionEndHour; return d.hour>=SessionStartHour||d.hour<SessionEndHour;}
int TodayEntries(){datetime from=StringToTime(TimeToString(TimeCurrent(),TIME_DATE)); if(!HistorySelect(from,TimeCurrent()))return 0; int n=0; uint total=HistoryDealsTotal(); for(uint i=0;i<total;i++){ulong t=HistoryDealGetTicket(i); if(t==0)continue; if((ulong)HistoryDealGetInteger(t,DEAL_MAGIC)==Magic && (long)HistoryDealGetInteger(t,DEAL_ENTRY)==DEAL_ENTRY_IN)n++;} return n;}

bool PositionForEA(){for(int i=PositionsTotal()-1;i>=0;i--){ulong t=PositionGetTicket(i); if(t>0&&PositionSelectByTicket(t)){if(PositionGetString(POSITION_SYMBOL)==_Symbol&&(ulong)PositionGetInteger(POSITION_MAGIC)==Magic)return true;}}return false;}
int EAPositionCount(){int n=0; for(int i=PositionsTotal()-1;i>=0;i--){ulong t=PositionGetTicket(i); if(t>0&&PositionSelectByTicket(t)&&(ulong)PositionGetInteger(POSITION_MAGIC)==Magic)n++;} return n;}

bool SpreadOK(){MqlTick t; if(!SymbolInfoTick(_Symbol,t))return false; double p=SymbolInfoDouble(_Symbol,SYMBOL_POINT); if(p<=0)return false; return ((t.ask-t.bid)/p)<=MaxSpreadPoints;}

double EMA(ENUM_TIMEFRAMES tf,int period,int shift=1){int h=iMA(_Symbol,tf,period,0,MODE_EMA,PRICE_CLOSE); if(h==INVALID_HANDLE)return EMPTY_VALUE; double b[]; ArraySetAsSeries(b,true); double v=EMPTY_VALUE; if(CopyBuffer(h,0,shift,1,b)==1)v=b[0]; IndicatorRelease(h); return v;}
double ATR(ENUM_TIMEFRAMES tf,int shift=1){int h=iATR(_Symbol,tf,ATRPeriod); if(h==INVALID_HANDLE)return EMPTY_VALUE; double b[]; ArraySetAsSeries(b,true); double v=EMPTY_VALUE; if(CopyBuffer(h,0,shift,1,b)==1)v=b[0]; IndicatorRelease(h); return v;}
double Highest(ENUM_TIMEFRAMES tf,int n,int shift=1){int i=iHighest(_Symbol,tf,MODE_HIGH,n,shift); return i>=0?iHigh(_Symbol,tf,i):0;}
double Lowest(ENUM_TIMEFRAMES tf,int n,int shift=1){int i=iLowest(_Symbol,tf,MODE_LOW,n,shift); return i>=0?iLow(_Symbol,tf,i):0;}

bool UpTrend(){double f=EMA(TrendTF(),FastEMA),s=EMA(TrendTF(),SlowEMA); return f!=EMPTY_VALUE&&s!=EMPTY_VALUE&&f>s;}
bool DownTrend(){double f=EMA(TrendTF(),FastEMA),s=EMA(TrendTF(),SlowEMA); return f!=EMPTY_VALUE&&s!=EMPTY_VALUE&&f<s;}

bool BullBreakout(){double c=iClose(_Symbol,EntryTF(),1),o=iOpen(_Symbol,EntryTF(),1),atr=ATR(EntryTF(),1); double level=Highest(EntryTF(),BreakoutLookback,2); if(c<=level||level<=0)return false; if(!RequireBodyConfirmation)return true; return atr>0&&(c-o)>=MinBodyATR*atr;}
bool BearBreakout(){double c=iClose(_Symbol,EntryTF(),1),o=iOpen(_Symbol,EntryTF(),1),atr=ATR(EntryTF(),1); double level=Lowest(EntryTF(),BreakoutLookback,2); if(c>=level||level<=0)return false; if(!RequireBodyConfirmation)return true; return atr>0&&(o-c)>=MinBodyATR*atr;}

// Optional retest confirmation: price must revisit the breakout area on the live candle.
bool BullRetest(){double level=Highest(EntryTF(),BreakoutLookback,2); MqlTick t; if(!SymbolInfoTick(_Symbol,t)||level<=0)return false; return t.bid>=level;}
bool BearRetest(){double level=Lowest(EntryTF(),BreakoutLookback,2); MqlTick t; if(!SymbolInfoTick(_Symbol,t)||level<=0)return false; return t.ask<=level;}

int VolDigits(){double step=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP); int d=0; while(step<1.0&&d<8){step*=10.0;d++;} return d;}
double NormalizeVolumeDown(double v){double min=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN),max=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX),step=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP); if(step<=0||min<=0)return 0; if(v<min)return 0; v=MathMin(v,max); return NormalizeDouble(MathFloor(v/step)*step,VolDigits());}

// Important for tiny accounts: if the broker's minimum lot would risk more than the requested risk,
// the EA refuses the trade instead of silently oversizing the account risk.
double LotsForRisk(double stopDistance){if(stopDistance<=0)return 0; double equity=AccountInfoDouble(ACCOUNT_EQUITY); double money=equity*RiskPercent/100.0; double tv=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE); double ts=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE); double min=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN); if(tv<=0||ts<=0||min<=0)return 0; double riskPerLot=(stopDistance/ts)*tv; if(riskPerLot<=0||riskPerLot*min>money)return 0; return NormalizeVolumeDown(money/riskPerLot);}

bool StopsValid(bool buy,double price,double sl,double tp){double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT); long stops=SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL); double minDist=stops*point; if(buy)return sl<price-minDist&&tp>price+minDist; return sl>price+minDist&&tp<price-minDist;}

void TryBuy(){MqlTick t; if(!SymbolInfoTick(_Symbol,t))return; double atr=ATR(EntryTF()),sr=Lowest(SRTF(),SRLookback,1); if(atr<=0||sr<=0)return; double sl=MathMin(sr,t.ask-ATRSLMult*atr); double dist=t.ask-sl; if(dist<=0)return; double tp=t.ask+dist*RiskReward; if(!StopsValid(true,t.ask,sl,tp))return; double lots=LotsForRisk(dist); if(lots<=0)return; double margin=0; if(!OrderCalcMargin(ORDER_TYPE_BUY,_Symbol,lots,t.ask,margin)||margin>AccountInfoDouble(ACCOUNT_MARGIN_FREE))return; trade.SetExpertMagicNumber(Magic); if(trade.Buy(lots,_Symbol,0,sl,tp,"TBB BUY"))g_lastTrade=TimeCurrent();}
void TrySell(){MqlTick t; if(!SymbolInfoTick(_Symbol,t))return; double atr=ATR(EntryTF()),sr=Highest(SRTF(),SRLookback,1); if(atr<=0||sr<=0)return; double sl=MathMax(sr,t.bid+ATRSLMult*atr); double dist=sl-t.bid; if(dist<=0)return; double tp=t.bid-dist*RiskReward; if(!StopsValid(false,t.bid,sl,tp))return; double lots=LotsForRisk(dist); if(lots<=0)return; double margin=0; if(!OrderCalcMargin(ORDER_TYPE_SELL,_Symbol,lots,t.bid,margin)||margin>AccountInfoDouble(ACCOUNT_MARGIN_FREE))return; trade.SetExpertMagicNumber(Magic); if(trade.Sell(lots,_Symbol,0,sl,tp,"TBB SELL"))g_lastTrade=TimeCurrent();}

int OnInit(){ResetDay(); trade.SetExpertMagicNumber(Magic); return INIT_SUCCEEDED;}
void OnTick(){
  if(!DailyGuard()||!InSession())return;
  if(TodayEntries()>=MaxTradesPerDay)return;
  if(EAPositionCount()>=MaxEAPositions||PositionForEA())return;
  if(g_lastTrade>0&&(TimeCurrent()-g_lastTrade)<CooldownMinutes*60)return;
  if(!SpreadOK())return;
  bool buy=UpTrend()&&BullBreakout(); bool sell=DownTrend()&&BearBreakout();
  if(RequireRetest){buy=buy&&BullRetest(); sell=sell&&BearRetest();}
  if(buy)TryBuy(); else if(sell)TrySell();
}
